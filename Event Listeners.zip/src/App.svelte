<script>
	function onClick(event) {
		if (event.target === element) {
			// d
		}
	}
// 	h1.addEventListener('click', onClick, )
</script>

<h1 on:click|preventDefault|stopPropagation|capture|nonpassive={onClick}>Event listeners</h1>

<div on:click|self={() => console.log('parent')}>
	parent
	<div on:click={() => {console.log('child')}}>
		child
	</div>
</div>