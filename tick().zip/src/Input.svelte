<script>
	import { tick } from 'svelte';
	let value = '';
	async function onInput(event) {
		const input = this;
		let selectionStart = input.selectionStart;
		let selectionEnd = input.selectionEnd;
		value = input.value.toUpperCase();
		
		await tick();

		input.selectionStart = selectionStart;
		input.selectionEnd = selectionEnd;
		// input.value = value;
	}
</script>

<input on:input={onInput} {value} >

<button on:click={() => {
	setTimeout(() => {
		console.log('timeout!')
		value = value.toUpperCase();
	}, 3000)
	
}}>
	update value
</button>