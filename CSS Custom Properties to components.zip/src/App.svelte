<script>
	import Button from './Button.svelte';
	let color = 'green';
</script>

<input type="color" bind:value={color} />

<div style="display: grid; grid-template-columns: 1fr 1fr 1fr;  --button-color: yellow; --text-color: black;">
	<Button buttonColor="red">
		Red Button
	</Button>
	<Button buttonColor="blue">
		Blue Button
	</Button>
	
	<div style="display:contents;--button-color: {color}; --text-color: white;">
		<Button>
			Yellow Button
		</Button>
	</div>
	
	<Button --button-color="{color}" --text-color="white">
		Yellow Button
	</Button>
</div>