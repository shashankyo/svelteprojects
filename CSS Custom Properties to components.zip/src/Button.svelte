<button style="
  background-color: var(--button-color, red);
  color: var(--text-color, white)">
	<slot />
</button>
<button style="
  background-color: var(--button-color, red);
  color: var(--text-color, white)">
	<slot />
</button>
