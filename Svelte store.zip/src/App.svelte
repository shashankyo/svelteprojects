<script>
	import Input from './Input.svelte';
	import Grandparent from './Grandparent.svelte';
	
	let value;
</script>

<Input />
<Grandparent />