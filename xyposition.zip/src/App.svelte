<script>
	import { onMount } from 'svelte';
	let x=0, y=0;
	
	onMount(() => {
		function move(event){
			x = event.clientX;
			y = event.clientY;
		}
		document.body.addEventListener("mousemove", move);
		return()=>{
			document.body.addEventListener("mousemove", move);
		}
	})
	$:console.log(x,y);
</script>
Mouse Position:{x},{y} 