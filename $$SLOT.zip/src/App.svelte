<script>
	import A from './A.svelte';
</script>

<A/>

<A>
		<div slot = "a">
			something for a
	</div>
			<div slot = "b">
			something for b
	</div>
			<div slot = "c">
			something for c
	</div>
</A>