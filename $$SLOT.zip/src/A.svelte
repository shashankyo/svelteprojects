<div>
	A:<slot name = 'a'>Fallback for a </slot>
</div>
<div>
	B:<slot name = 'b'>Fallback for b </slot>
</div>
<div>
	C:<slot name = 'c'>Fallback for c </slot>
</div>

