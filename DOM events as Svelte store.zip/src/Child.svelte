<script>
	import mousePosition from './mousePosition';
</script>

<div>
[Children] Mouse position: {$mousePosition.x},{$mousePosition.y}
</div>