<script>
	import Parent1 from './Parent1.svelte';
	import Parent2 from './Parent2.svelte';
</script>

<Parent1 />

<hr />

<Parent2 />