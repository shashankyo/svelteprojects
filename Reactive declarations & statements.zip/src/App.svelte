<script>
	let count = 1;
// 	let double = count * 2;

	$: double = count * 2; // double -> count
	$: console.log('double:', double); // -> console, double 
	$: console.log('double2:', double); // -> console, double 
	
	$: quadruple = double * 2; // quadruple -> double	
// 	$: fullname = firstname + ' ' + lastname; // firstname, lastname
// 	$: sum = a + b + c; // a, b, c
// 	$: result = calculate(num1, num2) // num1, num2, calculate
// 	$: console.log('count', count); // console, count
// 	$: doSomething(a, b) // doSomething, a, b
	
// 	function doSomething(a, b) {
// 		console.log(a, b, count);
// 	}
	
	function increment() {
		count ++;
// 		$: double = count +2;
	}
	function decrement() {
		count --;
	}
	function multiply() {
		count = count * count;
	}
	
	function doSomething() {
		console.log(double)
	}
</script>

<button on:click={decrement}>-</button>
{count} * 2 = {double} * 2 = {quadruple}
<button on:click={increment}>+</button>
<button on:click={multiply}>scale</button>

<button on:click={doSomething}>Click Me</button>