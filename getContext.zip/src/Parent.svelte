<script>
	import Child from './Child.svelte';
</script>

<div style="border: 1px solid black;">
	Parent A
	<Child color="red" />
</div>