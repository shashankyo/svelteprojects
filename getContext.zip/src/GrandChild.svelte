<script>
	export let color;
</script>

<div style="color: {color}">GrandChild</div>