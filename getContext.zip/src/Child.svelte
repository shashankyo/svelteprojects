<script>
	import GrandChild from './GrandChild.svelte';
	
	export let color;
</script>

<GrandChild {color} />