<script>

</script>

<div>
	Header: <slot name="header" />
</div>
<div>
	Footer: <slot name="footer" />
</div>
