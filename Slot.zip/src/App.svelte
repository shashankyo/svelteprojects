<script>
	import Component from './Component.svelte';
	
	let count = 0;
</script>

<div>
	{count}
	<button on:click={() => count++}>+</button>
</div>

<Component>
	<slot:template slot="header">
		{count}
		<button on:click={() => count--}>-</button>
	</slot:template>
	
	<div slot="footer">
		element for footer
	</div>
</Component>

<Component />

<style>
	button {
		font-size: 42px;
	}
</style>