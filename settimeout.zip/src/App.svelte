<script>
	import { writable,derived } from 'svelte/store';
	
	const num = writable(10);
	const num2 = writable(42);
	//derived from 1 store
	const doubleOfNum = derived(num, (haha)=> {return haha * 2})
	//derived from multiple stores
		const multiplication = derived([num,num2], ([$num, $num2])=> {return $num * $num2});
	// get the derived value synchronously
	const delayedNum = derived(num, ($num, set) => {
		setTimeOut(() => {
					set($num);
		},1000);
		return ()=> {
			console.log('hi')
			cleanTimeout(timeoutId);
		}
	},'not set');
	// get the derived value asynchronously
</script>

<input bind:value={$num} type="number" />
<input bind:value={$num2} type="number" />

<div>
	{$num}*2= {$doubleOfNum}
</div>
<div>
	{$num}*{$num}= {$multiplication}
</div>
<div>
	delayed:{$delayedNum}
</div>