<script>
	import A from './A.svelte';
</script>

<A />

<A>
	<div slot="a"></div>
	<svelte:fragment slot="b"></svelte:fragment>
	<div slot="c">something for c</div>
</A>

<A>
	<div slot="a">something for a</div>
</A>