<div>
	A: <slot name='a'>Fallback for a</slot>
</div>

{#if $$slots.b}
	<div>
		B: <slot name='b'>fall</slot>
	</div>
{/if}

<div>
	C: <slot name='c'>Fallback for c</slot>	
</div>
