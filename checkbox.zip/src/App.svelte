<script>
	let flavours;
</script>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="1">1
</label>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="2">2
</label>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="3">3
</label>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="4">4
</label>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="5">5
</label>
<label>
	<input type= "radio" name="foo" bind:group={flavours} value ="6">6</label>





selected flavours {flavours}