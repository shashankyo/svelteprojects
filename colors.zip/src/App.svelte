<script>
	let colors = [
			{name:'red',hex: '#f00'},									{ name:'green',hex:'#0f0'},
			 {name:'yellow',hex:'#00f'},
			 {name:'orange',hex:'#f00'},
			 {name:'shashank',hex:'#ff0'},
	];
	for(const color of colors){
		console.log(color.name,color.hex);
	}
	
</script>

<ul>
	{#each colors as color}
		<li style="color:{color.hex};">{color.name}</li>
	{/each}
	
</ul>