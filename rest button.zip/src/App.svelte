<script>
// 	import {onMount} from 'svelte';
	let element;
	
	
// 	onMount(() => {
// 			console.log(element);
// 	})

	function reset(){
		element.value = '';
	}
</script>

<input bind:this={element}/>
<hr/>
<button on:click={reset}>Reset</button>