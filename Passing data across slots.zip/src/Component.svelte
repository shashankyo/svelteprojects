<script>
	let count = 0;
	
	function inc(delta) {
		count+=delta;
	}
</script>

<div>
	Component:
	<button on:click={() => count--}>-</button>
	{count}
	<button on:click={() => count++}>+</button>
</div>

<hr />

<slot count={count} {inc} />