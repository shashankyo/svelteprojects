<script>
	import Component from './Component.svelte';
	
	let count = 0;
	
	function inc(delta) {
		count+=delta;
	}
</script>

<button on:click={() => count--}>-</button>
{count}
<button on:click={() => count++}>+</button>

<Component>
	<svelte:fragment let:count={countFromComponent} let:inc={incFromComponent}>
		appCount {count}<br />
		componentCount: {countFromComponent}
		<hr />
		<button on:click={() => inc(countFromComponent)}>+</button>
		<button on:click={() => incFromComponent(count)}>+</button>
	</svelte:fragment>
</Component>