<script>
	let name = 'world';
</script>

<input bind:value={name} />

<div>
	{name}
</div>

<svelte:head>
	<title>{name}</title>
	<meta name="description" content="{name}"/>
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
	{@html `<style>:root {
			--font-color: ${name}
		}</style>`}
</svelte:head>

<style>
	div, input {
		font-family: 'Dancing Script', cursive;
		color: var(--font-color);
	}
</style>