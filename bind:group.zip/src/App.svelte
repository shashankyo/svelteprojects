<script>
	let options = ['3'];
	let options2 = [];
</script>

<button on:click={() => {
	options = ['4','1'];
	}}>
	reset
</button>

<label>
	<input type="checkbox" name="foo" bind:group={options} value="1"> 1
</label>
<label>
	<input type="checkbox" name="foo" bind:group={options} value="2"> 2
</label>
<label>
	<input type="checkbox" name="foo" bind:group={options} value="3"> 3
</label>
<label>
	<input type="checkbox" name="foo" bind:group={options} value="4"> 4
</label>

Selected Options: {options.join(', ')}

<!-- <label>
	<input type="radio" name="foo" bind:group={option} value="1"> 1
</label>
<label>
	<input type="radio" name="foo" bind:group={option} value="2"> 2
</label>
<label>
	<input type="radio" name="foo" bind:group={option} value="3"> 3
</label>
<label>
	<input type="radio" name="foo" bind:group={option} value="4"> 4
</label>

Selected Option: {option} -->