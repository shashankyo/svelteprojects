<script>
	import Parent from './Parent.svelte';
</script>

<Parent />