<script>
	import Output from './Output.svelte';
</script>

<Output />