<script>
	let obj = [];
	let count;
	
	function increment() {
		// 1. assignment
		count = 10;
		// 2. update statements	
		count ++;
		count += 2;
		// 3. updating / assiging a property
		obj.count++;
		obj.count = 10;
		
		// not an update to svelte
		const data = obj;
		data.count ++;
		
		// calling a method
		obj.push(1);
	}
	
	function doSomethingElse() {
		obj.foo = 1;
	}
</script>

{JSON.stringify(obj)}

<button on:click={increment}>
	Click Me
</button>

{count}

<button on:click={doSomethingElse}>Something else</button>