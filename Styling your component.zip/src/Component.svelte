<h1>Another Component</h1>

<p>Bye world</p>

<div class="links">
	<a href="https://github.com/">Link to my Repo</a>
</div>

<style>
	h1, p {
		animation: zoom 5s infinite;
	}
</style>