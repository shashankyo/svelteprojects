<script>
	let selectedBreed;
	const breeds = ['affenpinscher', 'african', 'airedale'];
	
	async function getRandomDogImage(breed) {
		const response = await fetch(`https://dog.ceo/api/breed/${breed}/images/random`);
		const obj = await response.json();
		return obj;
	}
</script>

<select bind:value={selectedBreed}>
	{#each breeds as breed}
		<option value={breed}>{breed}</option>
	{/each}
</select>

Selected Breed: {selectedBreed}

<hr />

{#await getRandomDogImage(selectedBreed)}
	loading...
{:then { message }}
	<img src={message} alt="dog" />
{:catch error}
	Oops. something's wrong.
{/await}