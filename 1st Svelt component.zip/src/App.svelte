<h1>My first Svelte component</h1>

<p>
	Hello world
</p>

<div>
	<a href="https://github.com/">Link to my Repo</a>
</div>

<style>
	h1 {
		color: red;
	}
	p {
		font-size: 44px;
		color:pink;
	}
</style>

<script>
	let name = 'shashank';
</script>